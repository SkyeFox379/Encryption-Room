function love.conf(t)
	t.window.title = "Global Game Jam 2018"
	t.window.width = 960
	t.window.height = 540

	t.modules.physics = false
end